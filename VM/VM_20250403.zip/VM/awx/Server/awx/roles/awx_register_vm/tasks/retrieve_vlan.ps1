param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$datacenter_name,
  [string]$dvswitch_name,
  [string]$project
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

$portgroup_name=-join('back_',$project)

$vlanid=Get-VDSwitch $dvswitch_name | Get-VDPortgroup | Select Name,@{N="VLANId";E={$_.Extensiondata.Config.DefaultPortCOnfig.Vlan.VlanId}} |grep -w $portgroup_name

$vlanid=$vlanid.split(' ')

$vlanid=$vlanid | tail -n 1

write-output $vlanid

param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$portgroup_name,
  [string]$lagname
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null
Get-VDPortgroup $portgroup_name | Get-VDUplinkTeamingPolicy | Format-table -HideTableHeaders |Out-File -Width 200 -FilePath /tmp/teaming
$uplinkx=Get-Content /tmp/teaming| select -Skip 1
$uplinkx=$uplinkx.split('{')[1]  
$uplinkx=$uplinkx.split(',')[0]
if ( $uplinkx -match "\}")
{
  $uplinkx=$uplinkx.split('}')[0]
  if ( $uplinkx -ne '')
  {
    Get-VDPortgroup $portgroup_name | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -UnusedUplinkPort $uplinkx
  }
  else
  {
    Get-VDPortgroup $portgroup_name | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort $lagname
    write-output "done"
  }
}
else
{
    Get-VDPortgroup $portgroup_name | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -UnusedUplinkPort $uplinkx
}

param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$datacenter_name,
  [string]$dvswitch_name,
  [string]$primaryvlan_id,
  [string]$project
)

function Get-dvSwitch{
	param($dcName,$dvSwName)
 
	$dcNetFolder = Get-View (Get-Datacenter $dcName | Get-View).NetworkFolder
	$found = $null
	foreach($net in $dcNetFolder.ChildEntity){
		if($net.Type -eq "VmwareDistributedVirtualSwitch"){
			$temp = Get-View $net
			if($temp.Name -eq $dvSwName){
				$found = $temp
			}
		}
	}
	$found
}


function Set-dVSwPgPVLAN{
	param($dvSw, $dvPgName, $pvlanNr)
 
	# Find the portgroup
	$dvSw.Portgroup | % {
		$dvPgTemp = Get-View -Id $_
		if($dvPgTemp.Name -eq $dvPgName){
			$dvPg = $dvPgTemp
		}
	}
 
	$spec = New-Object VMware.Vim.DVPortgroupConfigSpec
	$spec.defaultPortConfig = New-Object VMware.Vim.VMwareDVSPortSetting
	$spec.defaultPortConfig.vlan = New-Object VMware.Vim.VmwareDistributedVirtualSwitchPvlanSpec
	$spec.defaultPortConfig.vlan.pvlanId = $pvlanNr
 
	$dvPg.UpdateViewData()
	$spec.ConfigVersion = $dvPg.Config.ConfigVersion
 
	$taskMoRef = $dvPg.ReconfigureDVPortgroup_Task($spec)
 
	$task = Get-View $taskMoRef
	while("running","queued" -contains $task.Info.State){
		$task.UpdateViewData("Info")
	}
}


Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

$promiscuous = Get-VDSwitch $dvswitch_name | Get-VDSwitchPrivateVlan -PrivateVlanType Promiscuous  -ErrorAction SilentlyContinue | select-object PrimaryVlanId | Select-String -Pattern $primaryvlan_id
if ($promiscuous  -eq "" -or $promiscuous -eq $null)
{
  Get-VDSwitch $dvswitch_name | New-VDSwitchPrivateVlan -PrimaryVlanID $primaryvlan_id -SecondaryVlanId $primaryvlan_id -PrivateVlanType Promiscuous
}

$portgroup_exists = Get-VDSwitch $dvswitch_name | Get-VDPortgroup $project -ErrorAction SilentlyContinue

if ($portgroup -eq"" -or $portgroup -eq $null)
{
  $community=Get-VDSwitch $dvswitch_name | Get-VDSwitchPrivateVlan -PrivateVlanType Community
  if ($primaryvlan_id -eq "" -or $primaryvlan_id -eq $null)
  {
    $primaryvlan_id = $community | select-object PrimaryVlanId | tail -n 2 | select-object -first 1
    $primaryvlan_id = $primaryvlan_id.trim()
  }

  $secondary = $community | select-object SecondaryVlanId | tail -n 2 | select-object -first 1
  if ($secondary -eq "" -or $secondary -eq $null)
  {
    $secondary = '0'
  }
  $secondary = $secondary.trim()
  $secondary = $secondary -as [int]
  $secondary++

  Get-VDSwitch $dvswitch_name | New-VDSwitchPrivateVlan -PrimaryVlanID $primaryvlan_id -SecondaryVlanId $secondary -PrivateVlanType Community
  
  Get-VDSwitch $dvswitch_name | New-VDPortgroup -name $project

  $dvSW = Get-dvSwitch $datacenter_name $dvswitch_name
  
  Set-dvSwPgPVLAN $dvSW $project $secondary
}

param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$datacenter_name,
  [string]$dvswitch_name,
  [string]$vlan_back_id_min,
  [string]$vlan_back_id_max
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

$defaultvlanlist=$vlan_back_id_min..$vlan_back_id_max

$vlanlist=Get-VDSwitch $dvswitch_name | Get-VDPortgroup | Select @{N="VLANId";E={$_.Extensiondata.Config.DefaultPortCOnfig.Vlan.VlanId}} |grep [1-9]

if ($vlanlist -eq"" -or $vlanlist -eq $null)
{
  $vlan_back_id=$vlan_back_id_min
}
else
{  
  $vlanlist=$vlanlist | select -unique
  $vlanlist=$vlanlist.trim()
  $vlan_back_id_min="$([System.Convert]::ToInt32($vlan_back_id_min) - 1)"
  $vlan_back_id_max="$([System.Convert]::ToInt32($vlan_back_id_max) + 1)"
  $vlanlist=$vlanlist |where {$_ -gt $vlan_back_id_min}
  $vlanlist=$vlanlist |where {$_ -lt $vlan_back_id_max}
  if ($vlanlist -eq"" -or $vlanlist -eq $null)
  {
    $vlan_back_id_min="$([System.Convert]::ToInt32($vlan_back_id_min) + 1)"
    $vlan_back_id=$vlan_back_id_min
  }
  else
  {
    $freevlan=Compare-Object -ReferenceObject $defaultvlanlist -DifferenceObject $vlanlist | Select InputObject
    $freevlan=$freevlan |select-object -first 1 | tail -n 2
    $freevlan=$freevlan.trim()
    $vlan_back_id=$freevlan -ne ''
  }
}

write-output $vlan_back_id

Param (
    [string]$vcenter_hostname,
		[string]$vcenter_username,
		[string]$vcenter_password,
		[string]$vmname,
		[string]$hardware_version
    )

# Connect to the vCenter Server
Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

# Retrieve the VM
$vm = Get-VM -Name $vmname

if ($vm && (Get-VM -Name $vmname | Select-Object -ExpandProperty HardwareVersion) -ne $hardware_version) {
  Write-Host "Upgrading the VM hardware version to the version : $hardware_version"

  # Stop the VM if running
  if ($vm.PowerState -eq "PoweredOn") {
    Write-Host "Shutting down the VM..."
    Shutdown-VMGuest -VM $vm -Confirm:$false

    Write-Host "Waiting for the VM to power off..."
        do {
            Start-Sleep -Seconds 5
        } while ((Get-VM -Name $vmname).PowerState -ne "PoweredOff")
  }

  # Upgrade the Hardware version
  Write-Host "Updating hardware version..."
  Set-VM -VM $vm -HardwareVersion $hardware_version -Confirm:$false

  # Start the VM after upgrade
  Write-Host "Restarting the VM ..."
  Start-VM -VM $vm -Confirm:$false
}
else {
  Write-Host "Error : '$vmname' VM has not been found."
}

# Connect the network adapter
#$vm | Get-NetworkAdapter | Set-NetworkAdapter -StartConnected:$true -Confirm:$false

# Disconnect from the vCenter Server
Disconnect-VIServer -Server $vcenter_hostname -Confirm:$false
Param (
        [string]$vcenter_hostname,
		[string]$vcenter_username,
		[string]$vcenter_password,
		[string]$vmname,
                [string]$cluster_name,
		[string]$graphical_card
    )
	
# Connect to the VMware Host
Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

# Retrieve DRS group
$graphical_card
if ( $graphical_card -like '*t4*')
{
  $drsgroup = 'vm-t4'
}
else
{
  if ( $graphical_card -like '*v100*')
  {
    $drsgroup = 'vm-v100'
  }
  else
  {
  }
}

Write-Host "Adding virtual machine $vmname to DRS VM Group $drsgroup"
try
{
  Set-DrsClusterGroup $drsgroup -VM $vmname -Add
}
catch
{
  Write-Error "Error adding virtual machine $vmname to DRS VM Group $drsgroup in cluster $cluster_name"
} 

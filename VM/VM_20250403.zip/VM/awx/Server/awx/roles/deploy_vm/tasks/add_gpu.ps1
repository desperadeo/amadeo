Param (
        [string]$vcenter_hostname,
		[string]$vcenter_username,
		[string]$vcenter_password,
		[string]$vmname,
		[string]$vgpu
    )
	
# Connect to the VMware Host
Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

$vGpuSelection = $vgpu

# Collect the VM's that need to change the vGPU profile
$vms = Get-VM -Name $vmName

foreach ($vm in $vms)
{

    $vGPUDevices = $vm.ExtensionData.Config.hardware.Device | Where { $_.backing.vgpu}
    if ($vGPUDevices.Count -gt 0)
	{
		Write-Host "Remove existing vGPU configuration from VM:" $vm.Name
		foreach ($vGPUDevice in $vGPUDevices)
		{
			$controllerKey = $vGPUDevice.controllerKey
			$key = $vGPUDevice.Key
			$unitNumber = $vGPUDevice.UnitNumber
			$device = $vGPUDevice.device
			$summary = $vGPUDevice.Summary
		  
			$spec = New-Object VMware.Vim.VirtualMachineConfigSpec
			$spec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)
			$spec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
			$spec.deviceChange[0].operation = 'remove'
			$spec.deviceChange[0].device = New-Object VMware.Vim.VirtualPCIPassthrough
			$spec.deviceChange[0].device.controllerKey = $controllerKey
			$spec.deviceChange[0].device.unitNumber = $unitNumber
			$spec.deviceChange[0].device.deviceInfo = New-Object VMware.Vim.Description
			$spec.deviceChange[0].device.deviceInfo.summary = $summary
			$spec.deviceChange[0].device.deviceInfo.label = $device
			$spec.deviceChange[0].device.key = $key
			$_this = $VM  | Get-View
			$nulloutput = $_this.ReconfigVM_Task($spec)
		}
	}

	Write-Host "Adding new vGPU configuration from VM:" $vm.Name
	$vmSpec = New-Object VMware.Vim.VirtualMachineConfigSpec
    $vmSpec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)
    $vmSpec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $vmSpec.deviceChange[0].operation = 'add'
    $vmSpec.deviceChange[0].device = New-Object VMware.Vim.VirtualPCIPassthrough
    $vmSpec.deviceChange[0].device.deviceInfo = New-Object VMware.Vim.Description
    $vmSpec.deviceChange[0].device.deviceInfo.summary = ''
    $vmSpec.deviceChange[0].device.deviceInfo.label = 'New PCI device'
    $vmSpec.deviceChange[0].device.backing = New-Object VMware.Vim.VirtualPCIPassthroughVmiopBackingInfo
    $vmSpec.deviceChange[0].device.backing.vgpu = "$vGpuSelection"
	
    $vmobj = $vm | Get-View
    
	$reconfig = $vmobj.ReconfigVM_Task($vmSpec)
    if ($reconfig) {
        $changedVm = Get-VM $vm
        $vGPUDevice = $changedVm.ExtensionData.Config.hardware.Device | Where { $_.backing.vgpu}
       }   
}
Write-Host "Done with configuration"
timeout /t 15

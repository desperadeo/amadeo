Param (
        [string]$vcenter_hostname,
		[string]$vcenter_username,
		[string]$vcenter_password,
		[string]$vmname
    )

# Variable
$tagCategory = "Backup type"

# PowerCLIConfiguration
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Scope User -ParticipateInCEIP $false -Confirm:$false | out-null 

# Connect to the VMware Host
Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

# Retrieve the VM
$vm = Get-VM -Name $vmname

# Add tag according to the Operating System
if ($vm.Guest.GuestFamily -eq "windows") {
    $tagName = "Cohesity 3 months Windows"
} elseif ($vm.Guest.GuestFamily -eq "linux") {
    $tagName = "Cohesity 3 months Linux"
}

# Retrieve the tag
$tag = Get-Tag -Name $tagName -Category "$tagCategory" -ErrorAction SilentlyContinue

# Assign tag to the VM
New-TagAssignment -Tag $tag -Entity $vm -ErrorAction SilentlyContinue

# Déconnexion du serveur vCenter
Disconnect-VIServer -Server $vCenterServer -Confirm:$false
param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$datacenter_name,
  [string]$dvswitch_name,
  [string]$portgroup_name
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null


$back_vlanid = Get-VirtualSwitch -Name $dvswitch | Get-VirtualPortGroup -name $portgroup_name | Select @{N="VLANId";E={$_.Extensiondata.Config.DefaultPortCOnfig.Vlan.VlanId}} | ft -hide | tail -n2 | head -1

write-output $back_vlanid

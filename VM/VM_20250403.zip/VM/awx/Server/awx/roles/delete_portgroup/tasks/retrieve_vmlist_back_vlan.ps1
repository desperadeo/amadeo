param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$datacenter_name,
  [string]$dvswitch_name,
  [string]$portgroup_name
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null


$vms = Get-View -ViewType Network -Property Name,VM | where-object {$_.Name -eq "$portgroup_name"}

try
{
  $vmsname = Get-View -Id $vms.Vm -Property Name | Select-Object -ExpandProperty Name 
  write-output $vmsname
}
catch
{
  write-output '0'
}

﻿While($true){
    Get-Date | Out-File 'C:\Route-agent\route-agent.log' -Append
    sleep 10
}
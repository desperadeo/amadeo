param
(
  [string]$vcenter_hostname,
  [string]$vcenter_username,
  [string]$vcenter_password,
  [string]$project
)

Connect-VIServer -Server $vcenter_hostname -User $vcenter_username -Password $vcenter_password | Out-Null

$vm_folder = Get-Folder $project | Get-VM

write-output $vm_folder

import argparse
import smtplib
import email
import ssl


def parse_args():
    parser = argparse.ArgumentParser(description='Simple mail sender')
    parser.add_argument('--smtp-host', required=True)
    parser.add_argument('--smtp-port', required=True)
    parser.add_argument('--smtp-login', required=True)
    parser.add_argument('--smtp-password', required=True)
    parser.add_argument('--receiver-email', required=True)
    parser.add_argument('--receiver-fname', required=True)
    parser.add_argument('--receiver-lname', required=True)
    parser.add_argument('--vm-host', required=True)
    parser.add_argument('--vm-kind', required=True)
    return parser.parse_args()


def send_mail(smtp_server, smtp_port, login, password, receiver_email,
              receiver_fname, receiver_lname, vm_host, vm_kind):
    # context = ssl.create_default_context()
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls(context=ssl.create_default_context())
        server.login(login, password)
        body = """
Dear {1} {2},

Your {0} {3} has been deployed and will be reachable in 2 hours.

For more details, please, have a look at
https://wiki.unil.ch/ci/books/virtual-machines-for-research/page/introduction-to-the-virtual-machine-service

In case of problem, do not hesitate to send an email to helpdesk@unil.ch,
and put "DCSR VM" at the beginning of the subject.

Best regards,
The DCSR team
    """.format(vm_kind, receiver_fname, receiver_lname, vm_host)

        message = email.message.EmailMessage()
        message.set_default_type('text/plain')
        message['From'] = 'noreply@unil.ch'
        message['To'] = [receiver_email, 'dcsrmach@unil.ch', 'toan.nguyen@unil.ch']
        message['Subject'] = 'Subject: Your {0} is ready'.format(vm_kind)
        message.set_content(body)
        server.send_message(msg=message)


args = parse_args()
print(args)
send_mail(args.smtp_host, args.smtp_port, args.smtp_login, args.smtp_password,
          args.receiver_email, args.receiver_fname, args.receiver_lname,
          args.vm_host, args.vm_kind)

#!/usr/bin/env python3

import argparse
import json
import yaml
from requests import Session
import urllib3
urllib3.disable_warnings()


def parse():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', required=True)
    ap.add_argument('--user', required=True)
    ap.add_argument('--password', required=True)
    opts = ap.parse_args()
    return opts.host, opts.user, opts.password


class AWX:
    INVENTORIES = ['Global_dcsr_servers', 'Global_dcsr_vdi']
    EXCLUDE_HOSTS = ['awx.unil.ch', 'vdi-mgmt.ad.unil.ch', 'vdi-cosrv1.ad.unil.ch', 'katello.dcsr.unil.ch', 'ansible']

    def __init__(self, awx_host, awx_user, awx_password, dry_run=False):

        self.dry_run = dry_run
        self.awx_host = awx_host
        self.awx_user = awx_user
        self.awx_password = awx_password
        self.awx_endpoint = self.awx_host + '/api/v2'
        self.session = self.__auth()

    def __auth(self):
        session = Session()
        # Should remove that once certificate is fixed
        session.verify = False
        session.get(self.awx_host)
        session.auth = (self.awx_user, self.awx_password)
        session.headers.update({'content-type': 'application/json'})
        url = '{}/me/'.format(self.awx_endpoint)
        response = session.get(url)
        if response.status_code == 401:
            raise
        return session

    def __get(self, route, params=None):
        return self.session.get(self.awx_endpoint + route, params=params)
    
    def __put(self, route, params=None):
        return self.session.put(self.awx_endpoint + route, json=params)

    def _get_inventories(self):
        results =  {}
        finished = False
        page = '1'
        while not finished:
            r = self.__get('/inventories', params={'page': page})
            if r.ok:
                output = r.json()
                if ('next' in output) and (output['next']):
                    page = output['next'].split('=')[-1]
                else:
                    finished = True
                for result in output['results']:
                    inventory_name = (result['name'])
                    if inventory_name in self.INVENTORIES:
                        inventory_id = (result['id'])
                        results[inventory_name] = inventory_id
        return results

    def _get_hosts_from_inventory(self, inventory_id):
        results =  {}
        finished = False
        page = '1'
        while not finished:
            r = self.__get('/inventories/{}/hosts'.format(inventory_id), params={'page': page})
            if r.ok:
                output = r.json()
                if ('next' in output) and (output['next']):
                    page = output['next'].split('=')[-1]
                else:
                    finished = True
                for result in output['results']:
                    host_name = (result['name'])
                    if host_name not in self.EXCLUDE_HOSTS:
                        host_id = (result['id'])
                        results[host_name] = host_id
        return results

    def _get_variable_data_from_host(self, host_id):
        r = self.__get('/hosts/{}/variable_data'.format(host_id))
        if r.ok:
            return r.json()
        else:
            raise

    def update_ansible_hosts(self):
        for inventory_name, inventory_id in self._get_inventories().items():
            for host_name, host_id in self._get_hosts_from_inventory(inventory_id).items():
                var_data = self._get_variable_data_from_host(host_id)
                print(inventory_name + " - " + host_name)
                var_data['ansible_host'] = host_name
                r = self.__put('/hosts/{}/variable_data/'.format(host_id), params=var_data)


if __name__ == '__main__':
    host, user, password = parse()
    awx = AWX(host, user, password)
    awx.update_ansible_hosts()

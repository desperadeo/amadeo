---
name: VM Removal Issue Template
about: To be used for removing VM issues
title: 'VM `[name]` --> Décomissionnement'
labels: ''
assignees: ''

---

### Description:

- La VM `[name]` ....


### Liens:

*   **Fiche WIKI**: ...
*   **Ticket(s) OTOBO**: 
    - ...


### Workflow de progression: 

- [ ] Removing from Firewall rules
- [ ] Removing from F5 config
- [ ] Removing VIP from Netdot
- [ ] Removing from DCSR Resource webapp
- [ ] Removing from VMware Infrastructure
- [ ] Removing from Prometheus
- [ ] Removing from Tenable inventory
- [ ] Removing from Nessus scan task
- [ ] Removing from Wiki
- [ ] Removing from Netdot
- [ ] Removing from RHEL license portal
- [ ] Removing from centreon


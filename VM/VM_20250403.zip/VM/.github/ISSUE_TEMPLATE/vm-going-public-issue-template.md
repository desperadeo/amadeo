---
name: VM (Going public) Production Issue Template
about: To be used for new VM issues
title: 'VM [name] --> Mise en public'
labels: ''
assignees: ''

---

### Description:

- La VM `[name]` ....


### Informations techniques:

| VM Name | Internal IP | internal URL(s) | Public IP | Public URL |
|:-------:|:-----------:|:---------------:|:---------:|:----------:|
| ... | ... | ... | ... | ... |


### Liens:

*   **Fiche WIKI**: ...
*   **Ticket(s) OTOBO**: 
    - ...


### Workflow de progression: 

- [ ] 1. `DCSR`: Création de l'issue dans le repo `ci-dcsr/VM` et assignation des acteurs.
- [ ] 2. `Toan`: Réservation IP NetDot.
- [ ] 3. `Toan`: Documentation Wiki.
- [ ] 4. `Toan`: Migration VLAN 1283.    
- [ ] 5. `Toan`: Configuration IP Fixe.
- [ ] 6. `Toan`: Installation de l'Agent Prometheus.
- [ ] 7. `Toan`: Installation de l'Agent Nessus.
- [ ] 8. `Toan`: Scan Nessus.
- [ ] 9. `DCSR` `CH` : Analyse du résultat Nessus et correction des vulnérabilités.
    - [ ] 9.a `Marco`: Consultation en cas de litige sur une vulnérabilité.
- [ ] 10. `Ayman`: Réservation des ressources dans NetDot (nom de domaine publique + VIP F5). 
- [ ] 11. `Ayman`: Configuration F5.
    - [ ] 11.a `Ayman`: Configuration WAF F5 **[en option]**.
- [ ] 12. `DCSR` `CH`: Demande d'ouverture des Firewalls via le formulaire FWaaS.
- [ ] 13. `Ayman`: Ouverture des Firewalls.
- [ ] 14. `DCSR`: Validation du client et fermeture de l'issue.


>`DCSR`: Ingénieur de Recherche de la DCSR
>`CH`: Chercheur


### Liens utiles:
Voir procédure générale: https://github.unil.ch/ci-dcsr/VM/wiki/Going-public-%28North-south-traffic%29
Voir liste des VM publiques: https://wiki.unil.ch/ci/books/dcsr/page/machines-accessibles-depuis-internet

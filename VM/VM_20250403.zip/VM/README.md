###

AWX Environment Execution built on 2024-12-22

Ansible Core => 2.15.13

#### Ansible galaxy included :

- microsoft.ad:1.8.0
- redhatinsights.insights:1.3.0
- ansible.posix:2.0.0
- community.windows:2.3.0
- ansible.windows:2.6.0
- community.hashi_vault:6.2.0
- ansible.netcommon:7.1.0
- ansible.utils:5.1.2
- theforeman.foreman:5.1.0
- awx.awx:24.6.1
- community.vmware:5.2.0
- vmware.vmware:1.7.1
- community.general:10.1.0
